<?php
require_once "../Model/DTO/UserDTO.php";
require_once "../Model/DAO/Connection.php";



class UserDAO {
    private $pdo = null;
    public function __construct() {
    $this->pdo = Connection::getInstance();
}



 public function registerUser(UserDTO $userDTO) {
 try {

 $sql = "INSERT INTO user (nome, /*idade*/, email, senha)
 VALUES (:nome, /*:idade*/, :email, :senha)";

 $stmt = $this->pdo->prepare($sql);



 // Pegando os dados do objeto DTO
 $nome = $userDTO->getNome();
// $idade = $userDTO->getIdade();
 $email = $userDTO->getEmail();
 $senha = $userDTO->getSenha();



 // Inserindo os valores nos tokens
 $stmt->bindValue(":nome", $nome);
//$stmt->bindValue(":idade",$idade);
 $stmt->bindValue(":email", $email);
 $stmt->bindValue(":senha", $senha);



 // Executando a query
 $result = $stmt->execute();
 return $result;
 }
 catch (PDOException $e) {
 echo "Erro ao cadastrar usuário: " . $e->getMessage();
 return false;
 }

 }
}

?>