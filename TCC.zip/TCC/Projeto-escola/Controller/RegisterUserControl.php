<?php
// Recebendo os dados do formulário
$nome = $_POST["nome"];
//$idade = $_POST["idade"];
$email = $_POST["email"];
$senha = $_POST["senha"];



// Teste (debug): exibir os dados
// Esse trecho pode ser comentado após testar
/*var_dump($nome);
//var_dump($idade);
var_dump($email);
var_dump($senha);*/



// Agora vamos criar e preparar o objeto DTO
require_once "../Model/DTO/UserDTO.php";
require_once "../Model/DAO/UserDAO.php";



// Criar instância do DTO
$userDTO = new UserDTO();



// Cria e preenche o DTO
$userDTO = new userDTO();
$userDTO->setNome($nome);
//$userDTO->setIdade($idade);
$userDTO->setEmail($email);
$userDTO->setSenha($senha);



// Cria o DAO e cadastra o usuário
$userDAO = new UserDAO();
$result = $userDAO->registerUser($userDTO);
// Feedback simples
if ($result) {
 echo "<script>
    alert('Usuário cadastrado');
    window.location.href='../View/RegisterUser.php'
    </script>";
} else {
/* echo "<script>
    alert('Erro ao cadastrar usuário');
    window.history.back(); //Ou redirecione para outra página de erro
    </script>";
    */
}



/* Preencher o DTO com os dados capturados
$userDTO->setNome($nome);
//$userDTO->setIdade($idade);
$userDTO->setEmail($email);
$userDTO->setSenha($senha); */
// Aqui futuramente vamos passar o DTO para o DAO, que vai salvar no banco de dados



//Futuramente:
// Teste (debug): verificar se os dados estão encapsulados no objeto
echo "<pre>";
var_dump($userDTO);
echo "</pre>";




?>