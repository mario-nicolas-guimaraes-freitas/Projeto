<?php
require_once "../Model/DAO/UserDAO.php";
$userDAO = new UserDAO();
$allUsers = $userDAO->listUser();
?>