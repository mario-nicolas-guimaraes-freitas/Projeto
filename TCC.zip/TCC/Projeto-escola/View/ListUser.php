<?php require_once "../Controller/ListUserControl.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
 <meta charset="UTF-8">
 <title>Lista de Usuários</title>
 <style>
 table {
 border-collapse: collapse;
 width: 80%;
 margin: auto;
 }
th, td {
 border: 1px solid #ccc;
 padding: 8px;
 text-align: center;
 }
 th {
 background-color: #eee;
 }
 </style>
 </head>
<body>
 <h2 style="text-align: center;">Usuários Cadastrados</h2>
 <table>
 <tr>
 <th>ID</th>
 <th>Nome</th>
 <th>Email</th>
 <th>.</th>
 </tr>
 <?php foreach ($allUsers as $user) { ?>
 <tr>
 <td><?php echo $user['id']; ?></td>
 <td><?php echo $user['nome']; ?></td>
 <td><?php echo $user['email']; ?></td>
 <td>

 <a href="ListUser.php?id=<?= $user['id'] ?>" onclick="return
 confirm('Tem certeza que deseja excluir este usuário?')">
 <button>Excluir</button>
</a>

<a href="ChangeUser.php?id=<?= $user['id'] ?>">Alterar</a>

</td>
 </tr>

 

 <?php } ?>
 </table>
</body>
</html>