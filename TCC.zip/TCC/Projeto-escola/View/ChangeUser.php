<input type="text" name="nome" value="<?= $user['nome'] ?>" />
<input type="email" name="email" value="<?= $user['email'] ?>" />
<!-- demais campos -->
<input type="hidden" name="id" value="<?= $user['id'] ?>" />